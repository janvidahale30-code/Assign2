import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Grocery App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.green),
      home: const GroceryHome(),
    );
  }
}

class GroceryHome extends StatefulWidget {
  const GroceryHome({super.key});

  @override
  State<GroceryHome> createState() => _GroceryHomeState();
}

class _GroceryHomeState extends State<GroceryHome> {
  int cartCount = 0;
  final List<Product> cart = [];
  final Set<Product> favorites = {};

  void _addToCart(Product product) {
    setState(() {
      cart.add(product);
      cartCount = cart.length;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text("Added ${product.name} to cart!"),
          duration: const Duration(seconds: 1)),
    );
  }

  void _toggleFavorite(Product product) {
    setState(() {
      if (favorites.contains(product)) {
        favorites.remove(product);
      } else {
        favorites.add(product);
      }
    });
  }

  void _openCart() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CartScreen(cart: cart),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.green.shade700,
        elevation: 0,
        title: const Text('Fresh Grocery'),
        actions: [
          IconButton(icon: const Icon(Icons.search), onPressed: () {}),
          Stack(
            alignment: Alignment.topRight,
            children: [
              IconButton(
                icon: const Icon(Icons.shopping_cart_outlined),
                onPressed: _openCart,
              ),
              if (cartCount > 0)
                CircleAvatar(
                  radius: 8,
                  backgroundColor: Colors.red,
                  child: Text('$cartCount',
                      style:
                          const TextStyle(color: Colors.white, fontSize: 10)),
                )
            ],
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            const Text("Popular Products",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            SizedBox(
              height: 240,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: productList
                    .map((p) => ProductCard(
                          product: p,
                          onAdd: () => _addToCart(p),
                          isFavorite: favorites.contains(p),
                          onFavoriteToggle: () => _toggleFavorite(p),
                        ))
                    .toList(),
              ),
            ),
            const SizedBox(height: 24),
            const Text("Categories",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: const [
                CategoryItem(title: "Fruits", icon: Icons.apple),
                CategoryItem(title: "Veggies", icon: Icons.eco),
                CategoryItem(title: "Drinks", icon: Icons.local_drink),
                CategoryItem(title: "Bakery", icon: Icons.cake),
              ],
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        selectedItemColor: Colors.green.shade700,
        unselectedItemColor: Colors.grey,
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(
              icon: Icon(Icons.category), label: "Categories"),
          BottomNavigationBarItem(
              icon: Icon(Icons.favorite_border), label: "Favorites"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
        ],
      ),
    );
  }
}

// Product Model
class Product {
  final String name, imageUrl, deliveryTime;
  final double price, rating;

  Product({
    required this.name,
    required this.imageUrl,
    required this.price,
    required this.rating,
    required this.deliveryTime,
  });
}

List<Product> productList = [
  Product(
    name: 'Fresh Broccoli',
    imageUrl: 'https://cdn-icons-png.flaticon.com/512/2909/2909769.png',
    price: 2.99,
    rating: 4.5,
    deliveryTime: '30 min',
  ),
  Product(
    name: 'Red Apples',
    imageUrl: 'https://cdn-icons-png.flaticon.com/512/415/415682.png',
    price: 3.49,
    rating: 4.8,
    deliveryTime: '25 min',
  ),
  Product(
    name: 'Bananas',
    imageUrl: 'https://cdn-icons-png.flaticon.com/512/590/590685.png',
    price: 1.99,
    rating: 4.2,
    deliveryTime: '20 min',
  ),
  Product(
    name: 'Carrots',
    imageUrl: 'https://cdn-icons-png.flaticon.com/512/135/135620.png',
    price: 2.50,
    rating: 4.4,
    deliveryTime: '28 min',
  ),
  Product(
    name: 'Milk Bottle',
    imageUrl: 'https://cdn-icons-png.flaticon.com/512/1046/1046870.png',
    price: 1.20,
    rating: 4.7,
    deliveryTime: '18 min',
  ),
  Product(
    name: 'Oranges',
    imageUrl: 'https://cdn-icons-png.flaticon.com/512/415/415733.png',
    price: 3.99,
    rating: 4.6,
    deliveryTime: '22 min',
  ),
];

// Product Card
class ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback onAdd;
  final bool isFavorite;
  final VoidCallback onFavoriteToggle;

  const ProductCard({
    super.key,
    required this.product,
    required this.onAdd,
    required this.isFavorite,
    required this.onFavoriteToggle,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => showDialog(
        context: context,
        builder: (_) => ProductDetailDialog(product: product, onAdd: onAdd),
      ),
      child: Container(
        width: 160,
        margin: const EdgeInsets.only(right: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: const [
            BoxShadow(
                color: Colors.black12, blurRadius: 6, offset: Offset(0, 2))
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                Container(
                  height: 120,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(16)),
                    image: DecorationImage(
                        image: NetworkImage(product.imageUrl),
                        fit: BoxFit.contain),
                  ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: GestureDetector(
                    onTap: onFavoriteToggle,
                    child: Icon(
                      isFavorite ? Icons.favorite : Icons.favorite_border,
                      color: Colors.red,
                    ),
                  ),
                )
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(product.name,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 16)),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Text("\$${product.price}",
                  style: const TextStyle(fontSize: 14, color: Colors.grey)),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: RatingStars(rating: product.rating),
            ),
          ],
        ),
      ),
    );
  }
}

class RatingStars extends StatelessWidget {
  final double rating;
  const RatingStars({super.key, required this.rating});

  @override
  Widget build(BuildContext context) {
    int stars = rating.floor();
    return Row(
      children: List.generate(5, (index) {
        return Icon(index < stars ? Icons.star : Icons.star_border,
            color: Colors.orange, size: 16);
      }),
    );
  }
}

class ProductDetailDialog extends StatelessWidget {
  final Product product;
  final VoidCallback onAdd;

  const ProductDetailDialog(
      {super.key, required this.product, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(product.name),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.network(product.imageUrl, height: 100),
          const SizedBox(height: 10),
          Text('Price: \$${product.price}'),
          Text('Rating: ${product.rating}'),
          Text('Delivery: ${product.deliveryTime}'),
        ],
      ),
      actions: [
        TextButton(
            onPressed: () {
              onAdd();
              Navigator.pop(context);
            },
            child: const Text("Add to Cart")),
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Close")),
      ],
    );
  }
}

class CategoryItem extends StatelessWidget {
  final String title;
  final IconData icon;
  const CategoryItem({super.key, required this.title, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CircleAvatar(
          radius: 28,
          backgroundColor: Colors.green.shade100,
          child: Icon(icon, color: Colors.green.shade800, size: 30),
        ),
        const SizedBox(height: 6),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
      ],
    );
  }
}

class CartScreen extends StatelessWidget {
  final List<Product> cart;
  const CartScreen({super.key, required this.cart});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("My Cart")),
      body: cart.isEmpty
          ? const Center(child: Text("Your cart is empty"))
          : ListView.builder(
              itemCount: cart.length,
              itemBuilder: (context, index) {
                final product = cart[index];
                return ListTile(
                  leading: Image.network(product.imageUrl, width: 40),
                  title: Text(product.name),
                  subtitle: Text("\$${product.price}"),
                );
              },
            ),
    );
  }
}
